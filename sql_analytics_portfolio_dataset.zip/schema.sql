CREATE DATABASE IF NOT EXISTS sports_business_analytics;
USE sports_business_analytics;

CREATE TABLE locations (
    location_code VARCHAR(10) PRIMARY KEY,
    city VARCHAR(50),
    state CHAR(2)
);

CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    age INT,
    gender VARCHAR(30),
    location_code VARCHAR(10),
    customer_segment VARCHAR(30),
    employment_status VARCHAR(30),
    signup_date DATE,
    FOREIGN KEY (location_code) REFERENCES locations(location_code)
);

CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100),
    category VARCHAR(50),
    brand VARCHAR(50),
    price DECIMAL(10,2)
);

CREATE TABLE events (
    event_id INT PRIMARY KEY,
    event_date DATE,
    event_type VARCHAR(50),
    opponent VARCHAR(50),
    result VARCHAR(20),
    venue VARCHAR(100)
);

CREATE TABLE transactions (
    transaction_id INT PRIMARY KEY,
    customer_id INT,
    product_id INT,
    transaction_date DATE,
    quantity INT,
    discount_pct DECIMAL(5,2),
    unit_price DECIMAL(10,2),
    revenue DECIMAL(12,2),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE TABLE attendance (
    attendance_id INT PRIMARY KEY,
    customer_id INT,
    event_id INT,
    ticket_type VARCHAR(30),
    ticket_price DECIMAL(10,2),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (event_id) REFERENCES events(event_id)
);

CREATE TABLE campaigns (
    campaign_id INT PRIMARY KEY,
    campaign_name VARCHAR(100),
    channel VARCHAR(50),
    campaign_date DATE,
    campaign_cost DECIMAL(12,2)
);

CREATE TABLE campaign_responses (
    response_id INT PRIMARY KEY,
    campaign_id INT,
    customer_id INT,
    responded TINYINT,
    purchase_made TINYINT,
    FOREIGN KEY (campaign_id) REFERENCES campaigns(campaign_id),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);