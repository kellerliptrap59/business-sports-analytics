# SQL Portfolio Project — Main Questions

## Level 1: SQL Fundamentals
1. How many customers are in the database?
2. How many customers are in each location?
3. What is the average age of customers?
4. How many customers are in each customer segment?
5. What are the 10 best-selling products by quantity?
6. What are the 10 products generating the most revenue?
7. What is total revenue?
8. What is the average transaction value?

## Level 2: JOINs and Business Analysis
9. What is total revenue by customer segment?
10. What is total revenue by city?
11. Which product category generates the most revenue?
12. What is the average amount spent by customers in each segment?
13. Which customers have spent more than $500?
14. Which customers have attended at least 5 events?
15. What is the average ticket price by ticket type?
16. Which events had the highest attendance?
17. What is average attendance by opponent?
18. Do winning events have higher average attendance than losses?

## Level 3: Subqueries and CTEs
19. Which products generate more revenue than the average product?
20. Which customers have spent more than the average customer?
21. What percentage of customers have made more than one purchase?
22. What percentage of customers have attended more than one event?
23. Which customer segment has the highest average customer spend?
24. What are the top 5 customers by total spending?

## Level 4: Window Functions
25. Rank products by revenue within each product category.
26. Rank events by attendance.
27. Calculate each customer's total spending and their rank among all customers.
28. Calculate monthly revenue and month-over-month revenue growth.
29. Calculate each customer's first purchase date and most recent purchase date.
30. Identify each customer's first purchased product.

## Level 5: Marketing Analytics
31. Which marketing channel has the highest response rate?
32. Which campaign generated the most purchases?
33. Calculate purchase conversion rate by marketing channel.
34. Calculate estimated ROI for each marketing campaign.
35. Which customer segment responds best to marketing campaigns?

## Final Business Question
36. If management could focus its resources on only THREE areas, which products,
customer segments, locations, or marketing channels would you recommend?

Support your recommendation with SQL analysis and explain the business reasoning.